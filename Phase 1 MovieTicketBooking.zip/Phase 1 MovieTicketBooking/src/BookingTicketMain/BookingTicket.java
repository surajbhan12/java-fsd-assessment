package BookingTicketMain;
import Customer.CustomerDetails;
import java.util.*;
import Booking_Exception.InvalidPasswordException;
import Booking_Exception.InvalidUserException;
import Booking_Exception.PaymentException;
import Booking_Status.Book;
import Front_desk_Login.Login;
public class BookingTicket {

	public static void main(String[] args) throws InvalidUserException,InvalidPasswordException, PaymentException{
		ArrayList<String> username=new ArrayList<String>();
		ArrayList<String> password=new ArrayList<String>();
		boolean B[]=new boolean[15];
		for(int i=0;i<B.length;i++) {
				B[i]=false;
		}
		int i;
		Scanner sc1=new Scanner(System.in);
		username.add("FirstUser");
		password.add("FirstPassword");
		if(Login.validateUser(username,password)==true) {
			System.out.println("\nLogin Sucessfully !\n");
			while(true) {
				System.out.println("1. Update Password\n2. View Available Tickets\n3. Book Ticket\n4. Booking Status\n5. Exit");
				System.out.println("Enter choice :-");
				i=sc1.nextInt();
				switch(i){
				case 1:password.remove("FirstPassword");
						System.out.println("Enter new Password :-");
						String s1=sc1.next();
						password.add(s1);
						System.out.println("Password Updated Successfully !");
						break;
				case 2:Book.view(B);
					break;
				case 3:Book.book(B);
					break;
				case 4 :System.out.println("Enter Booking ID:-");
						String j=sc1.next();
						Book.checked(j);
					break;
				case 5 : System.exit(0);
					break;
				default:
					System.out.println("Enter correct choice !");
				}
			}
		}
		
	}
}
