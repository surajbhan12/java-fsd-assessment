package Booking_Exception;

public class InvalidPasswordException extends Exception {
	public String toString() {
		return "Invalid Password";
	}
}
