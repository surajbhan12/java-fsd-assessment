package Booking_Exception;

public class InvalidUserException extends Exception {
	public String toString() {
		return "Invalid User Name";
	}

}
