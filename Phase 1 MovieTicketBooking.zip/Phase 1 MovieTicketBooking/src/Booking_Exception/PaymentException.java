package Booking_Exception;

public class PaymentException extends Exception{
	public String toString() {
		return "Payment Not Clear !";
	}

}
