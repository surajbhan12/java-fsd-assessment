package Booking_Status;

import java.util.*;

import javax.swing.Spring;

import Booking_Exception.PaymentException;
import Customer.CustomerDetails;

public class Book {
	static String name;
	static String bid;
	static double pay;
	static ArrayList<CustomerDetails> acd=new ArrayList<>();
    public static void view(boolean[] b) {
    	System.out.println("Available Seats");
    	for(int i=0;i<b.length;i++) {
    			if(b[i]==false)
    			{
    				System.out.print("B"+(i+1)+","); 
    			}
    	}
    	System.out.println();
    }
    public static void book(boolean[] b) throws PaymentException {
    	double due=-1;
    	Scanner sc3=new Scanner(System.in);
    	System.out.println("Enter your name :- ");
    	name=sc3.nextLine();
    	System.out.println("Number of tickets :-");
    	int noOfTicket=sc3.nextInt();
    	int arr[]=new int[noOfTicket];
    	Book.view(b);
    	ArrayList<Integer> list=new ArrayList<>();
    	System.out.println("Choose Seat No :");
    	for(int i=0;i<noOfTicket;i++) {
    		int seatno=sc3.nextInt();
    		arr[i]=seatno;
    		list.add(seatno);
    	}
    	due=paymentcal(noOfTicket);
    	pay=sc3.nextDouble();
    	bid="Bid";
    	due=due-pay;
    	if(due==0) {
    		for(int z=0;z<noOfTicket;z++)
    			b[arr[z]-1]=true;
    		System.out.println("Ticket Booked !  Enjoy your Movie");
    		bid=bid+Math.random();
    		System.out.println(bid);
    	}else {
    		throw new PaymentException();
    	}
    	CustomerDetails cd=new CustomerDetails();
    	cd.setName(name);
    	cd.setDob(new Date());
    	cd.setBookid(bid);
    	cd.setPaydone(pay);
    	cd.setNumOfTicket(noOfTicket);
    	cd.setLis(list);
    	acd.add(cd);
    	
    }
    public static void checked(String id) {
    	int f=0;
    	for(CustomerDetails ccd:acd) {
    		if(ccd.getBookid().equals(id)) {
    			f=1;
    			System.out.println("NAME = "+ccd.getName()+"        Booking ID = "+ccd.getBookid());
    			System.out.println("Tickets : "+ccd.getNumOfTicket()+"         "+ "Payment = "+ccd.getPaydone());
    			System.out.println("Seat no = "+ccd.getLis());
    			System.out.println("                    Date : "+ccd.getDob()+"\n\n");
    			break;
    		}
    	}
    	if(f==0) {
    		System.out.println("Incorrect Booking ID !");
    	}
    	
    	}
    public static double paymentcal(int n){
    	double ticketCharge =150;
    	double dues=(double)n *ticketCharge;
    	System.out.println("Submit "+dues+" Rupees");
    	return dues;
    }
}