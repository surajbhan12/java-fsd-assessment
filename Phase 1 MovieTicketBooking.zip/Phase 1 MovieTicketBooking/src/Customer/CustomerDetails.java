package Customer;

import java.util.ArrayList;
import java.util.Date;

public class CustomerDetails {
	private String name;
	private ArrayList<Integer> lis=new ArrayList<>();
	private Date dob;
	private int numOfTicket;
	public int getNumOfTicket() {
		return numOfTicket;
	}
	public void setNumOfTicket(int numOfTicket) {
		this.numOfTicket = numOfTicket;
	}

	private double paydone;
	private String bookid;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Integer> getLis() {
		return lis;
	}
	public void setLis(ArrayList<Integer> lis) {
		this.lis = lis;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public double getPaydone() {
		return paydone;
	}
	public void setPaydone(double paydone) {
		this.paydone = paydone;
	}
	public String getBookid() {
		return bookid;
	}
	public void setBookid(String bookid) {
		this.bookid = bookid;
	}
	
	public String toString() {
		return "Name = "+name+"\nSeat NO. = "+lis+ "\nD.O.B = "+dob+"\nPayment = "+paydone+"\nBooking ID = "+bookid;
	}
	
	

}

