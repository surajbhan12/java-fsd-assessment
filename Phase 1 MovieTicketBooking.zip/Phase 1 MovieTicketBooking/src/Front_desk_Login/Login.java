package Front_desk_Login;
import java.util.ArrayList;
import java.util.Scanner;

import Booking_Exception.InvalidPasswordException;
import Booking_Exception.InvalidUserException;

public class Login {
		
	public static boolean validateUser(ArrayList<String> username,ArrayList<String> password) throws InvalidUserException , InvalidPasswordException{
		Scanner sc=new Scanner(System.in);
		boolean us,pass;
		System.out.println("Enter user name :-");
		String s=sc.next();
		us=username.contains(s);
		System.out.println("Enter password :-");
		String sb=sc.next();
		pass=password.contains(sb);
		if(us==false) {
			throw new InvalidUserException();
		}else if(pass==false) {
			throw new InvalidPasswordException();
		}
	return (us&&pass);
	}		
}
