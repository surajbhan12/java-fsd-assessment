

public class ClassList {
	private int cid;
	private String Cname;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	@Override
	public String toString() {
		return "Class [cid=" + cid + ", Cname=" + Cname + "]";
	}
	
}
