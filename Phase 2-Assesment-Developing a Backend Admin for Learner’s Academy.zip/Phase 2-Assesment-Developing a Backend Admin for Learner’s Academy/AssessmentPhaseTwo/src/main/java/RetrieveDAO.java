import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RetrieveDAO {

	public ResultSet retrieveclass() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		     Connection con= DbUtil.getCon();
			// TODO Auto-generated catch block
			Statement st=con.createStatement();
			String sql="select * from class";
			//select
			ResultSet rs=st.executeQuery(sql);
		
		return rs;
	}

	public int insertClass(ClassList c) throws ClassNotFoundException, SQLException {
		Connection con= DbUtil.getCon();
		String sql="insert into class values(?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, c.getCid());
		ps.setString(2, c.getCname());
		int row=ps.executeUpdate();
		return row;
	}

	public void update(ClassList c) throws ClassNotFoundException, SQLException {
		Connection con= DbUtil.getCon();
		Statement st=con.createStatement();
		//insert,update,delete->int value -no of rows
		String sql="update class set classname='"+c.getCname()+"'where id="+c.getCid();
		st.executeUpdate(sql);
		
	}

	public void delete(int id) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con= DbUtil.getCon();
		Statement st=con.createStatement();
		String sql="delete from class where id ="+id;
		st.executeUpdate(sql);
	}
	

}
