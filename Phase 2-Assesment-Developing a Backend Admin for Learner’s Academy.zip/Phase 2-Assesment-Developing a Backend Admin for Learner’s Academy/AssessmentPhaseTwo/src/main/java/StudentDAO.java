import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentDAO {

	public int insert(Student s) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con= DbUtil.getCon();
		String sql="insert into student values(?,?,?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, s.getSid());
		ps.setString(2, s.getFname());
		ps.setString(3, s.getLname());
		ps.setString(4, s.getAddress());
		ps.setInt(5, s.getPhone());
		ps.setInt(6, s.getCid());
		int row=ps.executeUpdate();
		return row;
	}

	public ResultSet retrieve(int cid) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con= DbUtil.getCon();
		// TODO Auto-generated catch block
		Statement st=con.createStatement();
		String sql="select s.sid,s.firstname,s.lastname ,s.address,s.phone,c.classname from student s,class c where s.cid=c.id and s.cid="+cid;
		//select
		ResultSet rs=st.executeQuery(sql);
	
	return rs;
	}

	public void delete(int sid) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con= DbUtil.getCon();
		// TODO Auto-generated catch block
		Statement st=con.createStatement();
		String sql="delete from student where sid="+sid;
		//select
		st.executeUpdate(sql);
	}

	public void update(Student s) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con= DbUtil.getCon();
		// TODO Auto-generated catch block
		Statement st=con.createStatement();
		String sql="update Student set firstname='"+s.getFname()+"',lastname='"+s.getLname()+"',address='"+s.getLname()+"',phone="+s.getPhone()+",cid="+s.getCid()+" where sid="+s.getSid();
		//select
		st.executeUpdate(sql);
	}

}
