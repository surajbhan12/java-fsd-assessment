import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SubjectDAO {

	public int insertSub(Subject sb) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con= DbUtil.getCon();
		String sql="insert into subject values(?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, sb.getSid());
		ps.setString(2, sb.getSname());
		int row=ps.executeUpdate();
		return row;
	}

	public int insertTe(Teacher te) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con= DbUtil.getCon();
		String sql="insert into Teacher values(?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, te.getId());
		ps.setString(2, te.getTname());
		int row=ps.executeUpdate();
		return row;
	}

	public ResultSet retrievesubject() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		 Connection con= DbUtil.getCon();
			// TODO Auto-generated catch block
			Statement st=con.createStatement();
			String sql="select s.id,s.subjectname,t.teachername from subject s,teacher t where s.id=t.id";
			//select
			ResultSet rs=st.executeQuery(sql);
		
		return rs;
	}
	

}
