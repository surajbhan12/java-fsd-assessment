

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class retrieve
 */
public class retrieve extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public retrieve() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
             RetrieveDAO dao=new RetrieveDAO();
		try {
			ResultSet rs=dao.retrieveclass();
			PrintWriter pw=response.getWriter();
			response.setContentType("text/html");
			pw.print(
					"<html>"
					+ "<body>"
					+ "<form action=\"Add.html\">"
					+ "<input type='Submit'  value='Add New Class'>"
					+ "</form>"
					+ "</body>"
					+ "</html>"
					);
			while(rs.next()) {
				pw.print(rs.getInt(1)+" "+rs.getString(2));
				pw.print(
						"<html>"
						+ "<body>"
						+ "&nbsp;&nbsp;<a href=\"Edit.html\">Edit</a>&nbsp;&nbsp;"
						+ "<a href=\"Delete.html\">Delete</a>&nbsp;&nbsp;"
						+ "<a href=\"AddTS.html\">Subject and Teacher </a>&nbsp;&nbsp;"
						+ "<a href=\"Report.html\">Class Report </a><br>"
						+ "</body>"
						+ "</html>"
						);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
