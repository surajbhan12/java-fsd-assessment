export class EmployeeModel{
    id:number=0;
    fname:string='';
    lname:string='';
    email:string='';
 }