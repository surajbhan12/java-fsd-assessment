let quiz=[
    {
        question:"What is the size of float and double in java?",
        option:[
            "1) 32 And 64",
            "2) 32 And 32",
            "3) 64 And 64",
            "4) 64 And 32",
        ],
        answer:1,
    },
    {
        question:"Select the valid statement.",
        option:[
            "1) char[] ch = new char()",
            "2) char[] ch = new char(5)",
            "3) char[] ch = new char[5]",
            "4) char[] ch = new char[]",
            
        ],
        answer:3,
    },
    {
        question:"Which attribute is not essential under <iframe>?",
        option:[
            "1. frameborder",
            "2. width",
            "3. height",
            "4. src",   
        ],
        answer:1,
    },
    {
        question:"Arrays in java are- ?",
        option:[
            "1. Primitive data types",
            "2. Object Reference",
            "3. Object",
            "4. None of the mentioned",   
        ],
        answer:3,

    },
    {
        question:"When is the object created with new keyword?",
        option:[
            "1. At compile time",
            "2. At run time",
            "3. Depends on code",
            "4. None",
               
        ],
        answer:2,
    }
]